# LCSocketDemo
基于CocoaAsyncSocke库的，创建，连接，发送，解包等操作演示

Demo 提供了2个项目：
LCSocketClient 和 LCSocketServer 分别对应客户端 Socket 和服务端 Socket
